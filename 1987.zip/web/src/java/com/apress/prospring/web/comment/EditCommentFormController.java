/*
 * Created on 11-Aug-2004
 */
package com.apress.prospring.web.comment;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.validation.BindException;
import org.springframework.validation.Errors;
import org.springframework.web.bind.RequestUtils;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.multipart.support.ByteArrayMultipartFileEditor;
import org.springframework.web.servlet.ModelAndView;

import com.apress.prospring.domain.Attachment;
import com.apress.prospring.domain.Comment;
import com.apress.prospring.domain.User;
import com.apress.prospring.web.AbstractBlogManagerFormController;

/**
 * @author janm
 */
public class EditCommentFormController extends AbstractBlogManagerFormController {

	/**
	 * .ctor
	 *
	 */
	public EditCommentFormController() {
		setFormView("comment-edit");
		setSuccessView("comment-posted");
		setSessionForm(false);
		setBindOnNewForm(true);

	}

	/* (non-Javadoc)
	 * @see org.springframework.web.servlet.mvc.AbstractFormController#formBackingObject(javax.servlet.http.HttpServletRequest)
	 */
	protected Object formBackingObject(HttpServletRequest request) throws Exception {
		int commentId = RequestUtils.getIntParameter(request, "commentId", 0);
		CommentForm comment = new CommentForm();
		if (commentId == 0) {
			comment.setPostedBy(User.ROOT);
			comment.setPostDate(new Date());
			comment.setEntry(RequestUtils.getRequiredIntParameter(request, "entry"));
		} else {
			Comment c = getBlogManager().getComment(commentId); 
			comment.setBody(c.getBody());
			comment.setCommentId(c.getCommentId());
			comment.setEntry(c.getEntry());
			comment.setPostDate(c.getPostDate());
			comment.setPostedBy(c.getPostedBy());
			comment.setReplyTo(c.getReplyTo());
			comment.setSubject(c.getSubject());
		}

		return comment;
	}

	/* (non-Javadoc)
	 * @see org.springframework.web.servlet.mvc.AbstractFormController#referenceData(javax.servlet.http.HttpServletRequest, java.lang.Object, org.springframework.validation.Errors)
	 */
	protected Map referenceData(HttpServletRequest request, Object command, Errors errors) throws Exception {
		//Comment comment = (Comment)command;
		Map data = new HashMap();
		//data.put("comments", getBlogManager().getEntryComments(comment.getEntry()));
		return data;
	}

	/* (non-Javadoc)
	 * @see org.springframework.web.servlet.mvc.SimpleFormController#onSubmit(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse, java.lang.Object, org.springframework.validation.BindException)
	 */
	protected ModelAndView onSubmit(HttpServletRequest request, HttpServletResponse response, Object command, BindException errors) throws Exception {
		CommentForm comment = (CommentForm)command;
		Map<String, Object> model = new HashMap<String, Object>();
		if (comment.getReplyTo().intValue() == 0) comment.setReplyTo(null);
		model.put("entry", new Integer(comment.getEntry()));
		getBlogManager().saveComment(comment, User.ROOT);
		
		if (comment.getAttachment() != null) {
			Attachment attachment = new Attachment();
			attachment.setContentType("");
			attachment.setFileData(comment.getAttachment());
			attachment.setFileName("attachment.txt");
			getBlogManager().attachToComment(attachment, comment.getCommentId());
		}
		
		return new ModelAndView(getSuccessView(), model);
	}
	
	/* (non-Javadoc)
	 * @see org.springframework.web.servlet.mvc.BaseCommandController#initBinder(javax.servlet.http.HttpServletRequest, org.springframework.web.bind.ServletRequestDataBinder)
	 */
	protected void initBinder(HttpServletRequest request, ServletRequestDataBinder binder) throws Exception {
		binder.registerCustomEditor(byte[].class, new ByteArrayMultipartFileEditor());
	}
}