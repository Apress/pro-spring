/*
 * Created on 14-Nov-2004
 */
package com.apress.prospring.web.struts;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.springframework.beans.factory.BeanCreationException;
import org.springframework.beans.factory.InitializingBean;

import com.apress.prospring.business.BlogManager;

/**
 * @author janm
 */
public abstract class AbstractBlogManagerAction extends Action implements InitializingBean {

	private BlogManager blogManager;

	/**
	 * Implementations must override this method to perform their specific logic
	 * 
	 * @param mapping The mapping
	 * @param form The form
	 * @param request The request
	 * @param response The response
	 * @return ActionForward
	 * @throws Exception 
	 */
	protected abstract ActionForward executeInternal(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception;
	
	/* (non-Javadoc)
	 * @see org.apache.struts.action.Action#execute(org.apache.struts.action.ActionMapping, org.apache.struts.action.ActionForm, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	public final ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		return executeInternal(mapping, form, request, response);
	}

	/* (non-Javadoc)
	 * @see org.springframework.beans.factory.InitializingBean#afterPropertiesSet()
	 */
	public final void afterPropertiesSet() throws Exception {
		if (blogManager == null) throw new BeanCreationException("Must set blogManager"); 
	}
	
	/**
	 * Gets the blogManager implementation
	 * @return The implementation
	 */
	protected final BlogManager getBlogManager() {
		return blogManager;
	}
	
	/**
	 * Sets the blogManager
	 * @param blogManager The blogManager 
	 */
	public final void setBlogManager(BlogManager blogManager) {
		this.blogManager = blogManager;
	}
}
