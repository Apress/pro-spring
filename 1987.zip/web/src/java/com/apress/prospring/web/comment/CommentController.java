/*
 * Created on 11-Aug-2004
 */
package com.apress.prospring.web.comment;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.BeanCreationException;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.web.bind.RequestUtils;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.apress.prospring.business.BlogManager;
import com.apress.prospring.web.security.SessionSecurityManager;
 
/**
 * Comment controller
 * 
 * @author janm
 */
public class CommentController extends MultiActionController implements InitializingBean {

	private BlogManager blogManager;

	/**
	 * Handles comment/index.html => displays all comments for the specified entry
	 */
	public ModelAndView handleIndex(HttpServletRequest request, HttpServletResponse response) throws Exception {
		int entryId = RequestUtils.getRequiredIntParameter(request, "entry");
		Map<String, Object> model = new HashMap<String, Object>();
		model.put("entry", blogManager.getEntry(entryId));
		return new ModelAndView("comment-index", model);
	}
	
	/**
	 * Handles comment/view.html?commentId={0}
	 */
	public ModelAndView handleView(HttpServletRequest request, HttpServletResponse response) throws Exception {
		Map<String, Object> model = new HashMap<String, Object>();
		model.put("comment", blogManager.getComment(RequestUtils.getRequiredIntParameter(request, "commentId")));
		return new ModelAndView("comment-view", model);
	}
	
	/**
	 * Handles comment/delete.html?commentId={0}[&confirm={1}]
	 */
	public ModelAndView handleDelete(HttpServletRequest request, HttpServletResponse response) throws Exception {
		boolean confirm = RequestUtils.getIntParameter(request, "confirm", 0) == 1;
		int commentId = RequestUtils.getRequiredIntParameter(request, "commentId");
		Map<String, Object> model = new HashMap<String, Object>();
		if (confirm) {
			blogManager.deleteComment(commentId, SessionSecurityManager.getUser(request));
			model.put("entry", new Integer(RequestUtils.getRequiredIntParameter(request, "entry")));
			return new ModelAndView("comment-deleted", model);
		} else {
			model.put("comment", blogManager.getComment(commentId));
			return new ModelAndView("comment-delete", model);
		}
	}
	
	/* (non-Javadoc)
	 * @see org.springframework.beans.factory.InitializingBean#afterPropertiesSet()
	 */
	public void afterPropertiesSet() throws Exception {
		if (blogManager == null) throw new BeanCreationException("Must set blogManager on commentController");
	}

	/**
	 * @param blogManager The blogManager to set.
	 */
	public void setBlogManager(BlogManager blogManager) {
		this.blogManager = blogManager;
	}
}