/*
 * Created on 11-Aug-2004
 */
package com.apress.prospring.web.admin.audit;

import java.util.Calendar;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.bind.RequestUtils;
import org.springframework.web.servlet.ModelAndView;

import com.apress.prospring.web.AbstractBlogManagerController;

/**
 * @author janm
 */
public class AuditController extends AbstractBlogManagerController {

	/* (non-Javadoc)
	 * @see org.springframework.web.servlet.mvc.Controller#handleRequest(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception {
		int purgeMonths = RequestUtils.getIntParameter(request, "purgeMonths", -1);
		if (purgeMonths != -1) {
			Calendar c = Calendar.getInstance();
			c.add(Calendar.MONTH, -purgeMonths);
			getAuditService().purgeAudit(c.getTime());
		}
		return new ModelAndView("admin-audit-index", "auditRecords", getAuditService().getAllAuditEntries());
	}

}
