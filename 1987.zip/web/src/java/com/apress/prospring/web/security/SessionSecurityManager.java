/*
 * Created on 08-Nov-2004
 */
package com.apress.prospring.web.security;

import javax.servlet.http.HttpServletRequest;

import com.apress.prospring.domain.User;


/**
 * @author janm
 */
public class SessionSecurityManager {

	private static final String USER_SESSION_KEY = "_user";
	
	/**
	 * Gets the User from the session
	 * 
	 * @param request The current request
	 * @return The User object
	 */
	public static User getUser(HttpServletRequest request) {
		User user = (User)request.getSession().getAttribute(USER_SESSION_KEY); 
		if (user == null) {
			user = User.ANONYMOUS;
		}
		
		return user;
	}

	/**
	 * Sets the user attribute to the sesssion
	 * 
	 * @param request The current request
	 * @param user The user to set. Cannot be null
	 */
	public static void setUser(HttpServletRequest request, User user) {
		if (user == null) throw new NullPointerException("User cannot be null");
		request.getSession().setAttribute(USER_SESSION_KEY, user);
	}
	
	/**
	 * Indicates whether a user is logged in
	 * 
	 * @param request The request
	 * @return T/F
	 */
	public static boolean isUserLoggedIn(HttpServletRequest request) {
		return request.getSession().getAttribute(USER_SESSION_KEY) != null;
	}
}
