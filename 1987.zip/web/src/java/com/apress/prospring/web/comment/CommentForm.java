/*
 * Created on 08-Nov-2004
 */
package com.apress.prospring.web.comment;

import com.apress.prospring.domain.Comment;

/**
 * @author janm
 */
public class CommentForm extends Comment {

	private byte[] attachment;

	/**
	 * @return Returns the attachment.
	 */
	public byte[] getAttachment() {
		return attachment;
	}

	/**
	 * @param attachment The attachment to set.
	 */
	public void setAttachment(byte[] attachment) {
		this.attachment = attachment;
	}
}
