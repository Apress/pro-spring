/*
 * Created on 08-Nov-2004
 */
package com.apress.prospring.web.entry;

import com.apress.prospring.domain.Entry;

/**
 * @author janm
 */
public class EntryForm extends Entry {

	private byte[] attachment;

	/**
	 * @return Returns the attachment.
	 */
	public byte[] getAttachment() {
		return attachment;
	}

	/**
	 * @param attachment The attachment to set.
	 */
	public void setAttachment(byte[] attachment) {
		this.attachment = attachment;
	}
}
