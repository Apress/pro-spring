/*
 * Created on 11-Aug-2004
 */
package com.apress.prospring.web.tiles;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import com.apress.prospring.web.security.SessionSecurityManager;


/**
 * @author janm
 */
public class MenuTileController implements Controller {

	/* (non-Javadoc)
	 * @see org.springframework.web.servlet.mvc.Controller#handleRequest(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception {
		if (SessionSecurityManager.isUserLoggedIn(request)) {
			return new ModelAndView("tile-user", "user", SessionSecurityManager.getUser(request));
		} else {
			return new ModelAndView("tile-guest");
		}
	}

}
