/*
 * Created on 11-Aug-2004
 */
package com.apress.prospring.web;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.BeanCreationException;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.servlet.mvc.SimpleFormController;

import com.apress.prospring.business.BlogManager;

/**
 * @author janm
 */
public abstract class AbstractBlogManagerFormController extends SimpleFormController implements InitializingBean {

	private BlogManager blogManager;

	/* (non-Javadoc)
	 * @see org.springframework.beans.factory.InitializingBean#afterPropertiesSet()
	 */
	public final void afterPropertiesSet() throws Exception {
		if (blogManager == null) throw new BeanCreationException("Must set blogManager on AbstractBlogManagerFormController");
	}

	/* (non-Javadoc)
	 * @see org.springframework.web.servlet.mvc.BaseCommandController#initBinder(javax.servlet.http.HttpServletRequest, org.springframework.web.bind.ServletRequestDataBinder)
	 */
	protected void initBinder(HttpServletRequest request, ServletRequestDataBinder binder) throws Exception {
		super.initBinder(request, binder);
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy H:m:s");
		dateFormat.setLenient(false);
		binder.registerCustomEditor(Date.class, null, new CustomDateEditor(dateFormat, false));		
	}

	/**
	 * Gets the blogManager
	 * 
	 * @return Returns the blogManager.
	 */
	protected final BlogManager getBlogManager() {
		return blogManager;
	}

	/**
	 * Sets the blogManager
	 * 
	 * @param blogManager The blogManager to set.
	 */
	public final void setBlogManager(BlogManager blogManager) {
		this.blogManager = blogManager;
	}
}