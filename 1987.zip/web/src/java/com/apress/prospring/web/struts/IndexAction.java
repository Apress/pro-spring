/*
 * Created on 14-Nov-2004
 */
package com.apress.prospring.web.struts;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

/**
 * @author janm
 */
public class IndexAction extends AbstractBlogManagerAction {

	/* (non-Javadoc)
	 * @see com.apress.prospring.web.struts.AbstractBlogManagerAction#executeInternal(org.apache.struts.action.ActionMapping, org.apache.struts.action.ActionForm, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 */
	protected ActionForward executeInternal(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.setAttribute("entries", getBlogManager().getMostRecentEntries());
		return mapping.findForward("success");
	}
	
}