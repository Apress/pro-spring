/*
 * Created on 10-Aug-2004
 */
package com.apress.prospring.web.entry;

import java.util.Date;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.validation.BindException;
import org.springframework.validation.Errors;
import org.springframework.web.bind.RequestUtils;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.multipart.support.ByteArrayMultipartFileEditor;
import org.springframework.web.servlet.ModelAndView;

import com.apress.prospring.domain.Attachment;
import com.apress.prospring.domain.Entry;
import com.apress.prospring.web.AbstractBlogManagerFormController;
import com.apress.prospring.web.security.SessionSecurityManager;

/**
 * EditEntryController
 * 
 * @author janm
 */
public class EditEntryFormController extends AbstractBlogManagerFormController {

	/**
	 * .ctor
	 *
	 */
	public EditEntryFormController() {
		setFormView("entry-edit");
		setSuccessView("entry-posted");
		setBindOnNewForm(true);
		setSessionForm(false);
	}

	/* (non-Javadoc)
	 * @see org.springframework.web.servlet.mvc.AbstractFormController#formBackingObject(javax.servlet.http.HttpServletRequest)
	 */
	protected Object formBackingObject(HttpServletRequest request) throws Exception {
		int entryId = RequestUtils.getIntParameter(request, "entryId", 0);
		EntryForm form = new EntryForm();
		if (entryId != 0) {
			Entry entry = getBlogManager().getEntry(entryId);
			form.setBody(entry.getBody());
			form.setEntryId(entry.getEntryId());
			form.setPostDate(entry.getPostDate());
			form.setSubject(entry.getSubject());
		} else {
			form.setPostDate(new Date());
		}
		return form;
	}

	/* (non-Javadoc)
	 * @see org.springframework.web.servlet.mvc.AbstractFormController#referenceData(javax.servlet.http.HttpServletRequest, java.lang.Object, org.springframework.validation.Errors)
	 */
	protected Map referenceData(HttpServletRequest request, Object command, Errors errors) throws Exception {
		return super.referenceData(request, command, errors);
	}

	/* (non-Javadoc)
	 * @see org.springframework.web.servlet.mvc.SimpleFormController#onSubmit(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse, java.lang.Object, org.springframework.validation.BindException)
	 */
	protected ModelAndView onSubmit(HttpServletRequest request, HttpServletResponse response, Object command, BindException errors) throws Exception {
		EntryForm form = (EntryForm)command;
		getBlogManager().saveEntry(form, SessionSecurityManager.getUser(request));
		
		if (form.getAttachment() != null) {
			Attachment attachment = new Attachment();
			attachment.setContentType("");
			attachment.setFileData(form.getAttachment());
			attachment.setFileName("attachment.txt");
			getBlogManager().attachToEntry(attachment, form.getEntryId());
		}

		return new ModelAndView(getSuccessView());
	}

	/* (non-Javadoc)
	 * @see org.springframework.web.servlet.mvc.BaseCommandController#onBindAndValidate(javax.servlet.http.HttpServletRequest, java.lang.Object, org.springframework.validation.BindException)
	 */
	protected void onBindAndValidate(HttpServletRequest request, Object command, BindException errors) throws Exception {
		getValidator().validate(command, errors);
	}
	
	/* (non-Javadoc)
	 * @see org.springframework.web.servlet.mvc.BaseCommandController#initBinder(javax.servlet.http.HttpServletRequest, org.springframework.web.bind.ServletRequestDataBinder)
	 */
	protected void initBinder(HttpServletRequest request, ServletRequestDataBinder binder) throws Exception {
		binder.registerCustomEditor(byte[].class, new ByteArrayMultipartFileEditor());
	}	
}