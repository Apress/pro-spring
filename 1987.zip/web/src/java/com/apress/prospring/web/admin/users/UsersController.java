/*
 * Created on 11-Aug-2004
 */
package com.apress.prospring.web.admin.users;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;

import com.apress.prospring.web.AbstractBlogManagerMultiactionController;

/**
 * @author janm
 */
public class UsersController extends AbstractBlogManagerMultiactionController {

	/**
	 * Handles /admin/users/index.html
	 */
	public ModelAndView handleIndex(HttpServletRequest request, HttpServletResponse response) throws Exception {
		return new ModelAndView("admin-users-index", "users", getBlogManager().getAllUsers());
	}
	
}
