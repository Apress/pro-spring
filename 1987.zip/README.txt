This document contains instructions for building and running the SpringBlog sample application.

1. Creating the database
------------------------------------

The SpringBlog application runs on MySql 4. You can obtain MySQl 4 from http://www.mysql.com.

Connect to MySql as a user with create database privileges and execute the following command
to create the SpringBlog database:

	CREATE DATABASE prospring;

Once this command is finished, you can use the DDL script included with the source code 
download to populate this database with tables and sample data using the following
commands:

	USE prospring;
	\. /path/to/sql/script

You will find the SQL script in the data/src/sql folder of the code download.

Next you need to modify the connection details found in the 
${DOWNLOAD_ROOT}/business/src/resources/applicationContext-db.xml file to match valid
connection details for your database. Specifically, you need to make sure that the 
user configured in this file has read/write access to the tables in the prospring
database you just created.


2. Build the WAR file
------------------------------------

To build the WAR file, make sure you have Ant 1.6.x installed and then run it from within 
the directory containing this file (and the build.xml file). By default, the Ant build script
will create spring.war in the dist directory which is in the same directory as this file.


3. Deploying the WAR file in Tomcat
------------------------------------

The SpringBlog application should run on any Servlet 2.3-compliant servlet container. It has
been tested on Tomcat 5.0.28. You can obtain the latest Tomcat release from 
http://jakarta.apache.org.

Once you have installed Tomcat, simply copy the spring.war created in step 2 into the 
${TOMCAT_HOME}/webapps folder. 


4. Starting the Application
------------------------------------

Start Tomcat and MySql using the appropriate method for your platform and then point your browser
at http://localhost:8080/spring/index.html. If your Tomcat installation is on a different machine
 or uses a different port, remember to change the URL as appropriate.